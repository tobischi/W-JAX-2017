package demo.action;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import demo.dao.AttendanceDAO;
import demo.dao.DAOUtils;
import demo.dao.RunnerDAO;
import demo.form.RunnerAttendancesForm;
import demo.pojo.Attendance;
import demo.pojo.Runner;

public class UpdateRunnerAttendancesAction extends Action {

	public static final String FORWARD_showRunnerAttendances = "showRunnerAttendances";
	
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws SQLException, NamingException {

		final String runnerUsername = request.getUserPrincipal().getName();
		Runner runner = null;
		RunnerAttendancesForm runnerAttendancesForm = (RunnerAttendancesForm)form;

		Connection connection = null;
		boolean rollback = true;
		try {
			connection = DAOUtils.getConnection();
			connection.setAutoCommit(false);

			RunnerDAO runnerDAO = new RunnerDAO(connection);
			AttendanceDAO attendanceDAO = new AttendanceDAO(connection);

			runner = runnerDAO.loadRunnerByName(runnerUsername);
			// selectedMarathons
			if (request.getParameter("selectedMarathons") == null) {
				for (Attendance attendance : runnerAttendancesForm.getAttendances()) {
					attendance.setAttending(false);
				}
			}
			attendanceDAO.updateAttendances(runner, runnerAttendancesForm.getAttendances());
			connection.commit();
			rollback = false;
		} finally {
			if (connection != null) {
				if (rollback) connection.rollback();
				connection.close();
			}
		}
		
		request.setAttribute("runner", runner);
		request.setAttribute("attendancesList", runnerAttendancesForm.getAttendances());
		request.setAttribute("UpdateResultMessage", "Your data has been saved...");
		return mapping.findForward(FORWARD_showRunnerAttendances);
	}

	
	
}
