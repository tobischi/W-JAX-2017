TRUNCATE TABLE run;

DELETE FROM runner;

DELETE FROM marathon;

DELETE FROM app_user;

DELETE FROM app_role;

DELETE FROM imported_usage_logs;