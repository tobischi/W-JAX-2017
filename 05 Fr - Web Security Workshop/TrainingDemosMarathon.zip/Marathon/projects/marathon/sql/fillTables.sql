INSERT INTO marathon (title) VALUES ('Cologne-Marathon Volldistanz');
INSERT INTO marathon (title) VALUES ('Cologne-Marathon Halbdistanz');
INSERT INTO marathon (title) VALUES ('Cologne-Marathon Skater');
INSERT INTO marathon (title) VALUES ('Cologne-Marathon Handbiker');

INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi', 'Rudolf', 'Renner', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi01', 'Rudolf01', 'Renner01', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi02', 'Rudolf02', 'Renner02', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi03', 'Rudolf03', 'Renner03', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi04', 'Rudolf04', 'Renner04', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi05', 'Rudolf05', 'Renner05', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');   
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi06', 'Rudolf06', 'Renner06', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi07', 'Rudolf07', 'Renner07', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi08', 'Rudolf08', 'Renner08', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi09', 'Rudolf09', 'Renner09', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi10', 'Rudolf10', 'Renner10', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi11', 'Rudolf11', 'Renner11', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi12', 'Rudolf12', 'Renner12', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi13', 'Rudolf13', 'Renner13', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi14', 'Rudolf14', 'Renner14', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi15', 'Rudolf15', 'Renner15', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');   
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi16', 'Rudolf16', 'Renner16', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi17', 'Rudolf17', 'Renner17', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi18', 'Rudolf18', 'Renner18', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('rudi19', 'Rudolf19', 'Renner19', '1976-05-19', 'Rennweg 15', '50311', 'Bonn', '4711555512347654');

INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars', 'Lars', 'Langlauf', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars01', 'Lars01', 'Langlauf01', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars02', 'Lars02', 'Langlauf02', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars03', 'Lars03', 'Langlauf03', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars04', 'Lars04', 'Langlauf04', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars05', 'Lars05', 'Langlauf05', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');   
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars06', 'Lars06', 'Langlauf06', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars07', 'Lars07', 'Langlauf07', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars08', 'Lars08', 'Langlauf08', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars09', 'Lars09', 'Langlauf09', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars10', 'Lars10', 'Langlauf10', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars11', 'Lars11', 'Langlauf11', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars12', 'Lars12', 'Langlauf12', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars13', 'Lars13', 'Langlauf13', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars14', 'Lars14', 'Langlauf14', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars15', 'Lars15', 'Langlauf15', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');   
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars16', 'Lars16', 'Langlauf16', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars17', 'Lars17', 'Langlauf17', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars18', 'Lars18', 'Langlauf18', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');
INSERT INTO runner (username, firstname, lastname, date_of_birth, street, zip, city, creditcard_number)
   VALUES ('lars19', 'Lars19', 'Langlauf19', '1972-04-12', 'Langlaufstr. 33', '50311', 'Bonn', '5555471176893245');


INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (0, 18, 5212);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (0, 19, 5209);
   
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (1, 0, 14223);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (1, 1, 14523);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (1, 2, null);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (1, 3, 14412);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (1, 4, 14209);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (1, 5, 14021);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (1, 6, 13989);

INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (2, 10, 10212);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (2, 9, 9209);

INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (3, 12, 7212);
INSERT INTO run (marathon_id, runner_id, finishing_seconds) VALUES (3, 14, 6209);


INSERT INTO app_user (username, password) VALUES ('rudi', 'run4goal'); INSERT INTO app_role (username, rolename) VALUES ('rudi', 'runner');
INSERT INTO app_user (username, password) VALUES ('lars', 'langlauf'); INSERT INTO app_role (username, rolename) VALUES ('lars', 'runner');

INSERT INTO app_user (username, password) VALUES ('admin', '4dm1n'); INSERT INTO app_role (username, rolename) VALUES ('admin', 'administrator');

