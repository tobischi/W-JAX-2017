DROP TABLE run;

DROP TABLE runner;

DROP TABLE marathon;

DROP TABLE app_user;

DROP TABLE app_role;

DROP TABLE imported_usage_logs;