$(function() {
  
	  var detailRunnerSelected = null;
      $(document).ready(function() {
    	  $(".searchResult").hover(function(event) {
    		    //mouse on the item (hover)
    		    if (event.currentTarget != detailRunnerSelected) {
    		    	if (detailRunnerSelected != null) {
        		    	detailRunnerSelected.style.backgroundColor = "#FFFFFF";
    		    	}
        		    detailRunnerSelected = event.currentTarget;
    		    	event.currentTarget.style.backgroundColor = "#FFFFCC";
        		    var runnerId = event.currentTarget.getAttribute("data-runner");

        		    $("#profileDetails").html("<span class='shy'>Loading...</span>");


        		    
        		    
        			$.ajax({
        		    	  url: "admin/loadDynamicRunnerDetails.do?runner="+runnerId,
        		    	  dataType: "script",
        		    	  success: function() {
        		    		  
        		    

					// template with HTML *without* taintable content concatenated (just HTML with ID-based placeholders)
					$("#profileDetails").html("<table border='1' bgcolor='#fffff3'><tr>\
					 <td colspan='2'>Details of Runner <b id='runnerFirstname'></b>  <b id='runnerLastname'></b></td>\
					 </tr><tr><td>Address</td>\
					 <td><span id='runnerStreet'></span><br/><span id='runnerZipAndCity'></span></td>\
					 </tr><tr><td>Credit Card</td>\
					 <td><span id='runnerCard'></span></td>\
					 </tr></table>");
  
					// fill the ID-based placeholders using .text() instead of .html()
					$("#runnerFirstname").text(runner.firstname);
					$("#runnerLastname").text(runner.lastname);
					$("#runnerStreet").text(runner.street);
					$("#runnerZipAndCity").text(runner.zip+" "+runner.city);
					$("#runnerCard").text(runner.cc);



        		    	  }
        		    });


    		    
    		    }
    		}/*, function() {
    		    //mouse off the item
    		}*/);
      });
  
});



